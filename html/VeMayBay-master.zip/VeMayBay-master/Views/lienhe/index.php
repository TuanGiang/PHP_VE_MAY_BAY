<div class="row">
	<div class="col-sm-offset-1 col-sm-10 well">

		<h3 class="text-info"><strong>Liên hệ</strong></h3>
		<hr class="alert-info" />
		<div class="row">
			<div class="col-sm-4">
				<h4><i class="fa fa-mobile-phone fa-2x"></i> 098 884 90 96(Gặp Lợi)</h4>
				<h4><i class="fa fa-mobile-phone fa-2x"></i> 090 367 62 22(Gặp Việt)</h4>
				<h4><a href="http://www.facebook.com/baytructuyen/"><i class="fa fa-facebook fa-2x"></i> /baytructuyen</a></h4>
			</div>
			<div class="col-sm-4">
				<h4><a href="http://apps.facebook.com/baybayonline/"><i class="fa fa-facebook-square fa-2x"></i> /baybayonline</a></h4>
				<h4><a href="skype:Viet_nt134?call" ><i class="fa fa-skype fa-2x"></i> Viet_nt134</a></h4>
			</div>
			<div class="col-sm-4">
				<h4><a href="https://mail.google.com" ><i class="fa fa-envelope fa-2x"></i> vietnt134@gmail.com</a></h4>
				<h4><a href="https://plus.google.com/s/Lợi" ><i class="fa fa-google-plus-square fa-2x"></i> /s/Lợi</a></h4>
			</div>
			
		</div>
		<hr class="alert-info" />
		<p>
			<strong> Công ty Cổ Phần Đầu Tư - VNA</strong>
		</p>
		<p>

			Địa chỉ: <strong>23/9 Phan Đăng Lưu, Phường 3, Quận BT, HCM</strong>
		</p>
		<p>
			(Ngã tư Phan Đăng Lưu - Hoàng Hoa Thám)
		</p>
	</div>
</div>